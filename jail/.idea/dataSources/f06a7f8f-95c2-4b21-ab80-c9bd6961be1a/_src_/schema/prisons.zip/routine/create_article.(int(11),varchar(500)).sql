CREATE PROCEDURE `create_article`(`id_article` INT(11), `description` VARCHAR(500))
  INSERT INTO list_articles (id_article, description) VALUES (id_article, description)