CREATE PROCEDURE `create_prisoner`(`firstname` VARCHAR(45), `lastname` VARCHAR(45), `date_of_birth` DATE,
                                   `detention` DATE, `released` DATE, `id_prison` INT(11))
  BEGIN 
		INSERT INTO prisoners (firstname, lastname, date_of_birth, detention, released, id_prison) VALUES (firstname, lastname, date_of_birth, detention, released, id_prison);
    END