CREATE PROCEDURE `create_prisoners_has_articles`(`id_prisoner` INT(11), `id_article` INT(11))
  INSERT INTO prisoners_has_articles (id_prisoner, id_article) VALUES (id_prisoner, id_article)