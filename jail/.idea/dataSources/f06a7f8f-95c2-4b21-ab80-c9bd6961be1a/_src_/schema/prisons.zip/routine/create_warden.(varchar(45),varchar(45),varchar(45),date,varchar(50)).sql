CREATE PROCEDURE `create_warden`(`firstname`     VARCHAR(45), `lastname` VARCHAR(45), `email` VARCHAR(45),
                                 `date_of_birth` DATE, `password` VARCHAR(50))
  BEGIN
    INSERT INTO wardens (firstname, lastname, email, date_of_birth, password) VALUES (firstname, lastname, email, date_of_birth, password);
    END