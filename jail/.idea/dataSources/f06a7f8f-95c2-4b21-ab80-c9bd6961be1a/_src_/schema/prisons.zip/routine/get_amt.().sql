CREATE PROCEDURE `get_amt`()
  SELECT amt FROM amt WHERE id = 1