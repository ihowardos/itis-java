CREATE PROCEDURE `get_amt`(`id_prison` INT(11))
  BEGIN 
    IF (SELECT amt FROM amt WHERE id = id_prison) IS NULL THEN
    INSERT INTO amt (id, amt) VALUES (id_prison, 0);
    ELSE 
    SELECT amt FROM amt WHERE id = id_prison;
    END IF;
    END