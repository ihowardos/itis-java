CREATE TRIGGER `amt_prisoners`
AFTER INSERT ON `prisoners`
FOR EACH ROW
  UPDATE amt SET amt = (SELECT COUNT(*) FROM prisoners WHERE id_prison = NEW.id_prison) WHERE id = NEW.id_prison