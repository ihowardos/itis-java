CREATE TRIGGER `create_prisoner`
AFTER INSERT ON `prisoners`
FOR EACH ROW
  INSERT INTO prisoners_info (id_prisoner, reg_time) VALUES (NEW.id_prisoner, now())