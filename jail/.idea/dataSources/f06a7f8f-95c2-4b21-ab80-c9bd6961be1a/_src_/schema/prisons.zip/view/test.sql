CREATE VIEW `test` AS
  SELECT
    `prisons`.`wardens`.`firstname` AS `firstname`,
    `prisons`.`wardens`.`lastname`  AS `lastname`,
    `prisons`.`prisons`.`name`      AS `name`,
    `prisons`.`prisons`.`capacity`  AS `capacity`
  FROM `prisons`.`wardens`
    JOIN `prisons`.`prisons`
  WHERE (`prisons`.`prisons`.`id_warden` = `prisons`.`wardens`.`id_warden`)
  GROUP BY `prisons`.`wardens`.`id_warden`
  ORDER BY `prisons`.`prisons`.`capacity`